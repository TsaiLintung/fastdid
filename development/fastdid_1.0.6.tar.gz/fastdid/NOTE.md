multiple (>2) event!
add back fastglm
maybe use base period for time var covariate
state design explore